<script>
  import Header from '$lib/components/Header.svelte';
  import Blogs from '$lib/components/Blogs.svelte';
  import SwapBox from '$lib/components/SwapBox.svelte';
  import BalanceBox from '$lib/components/BalanceBox.svelte';

  import { balances } from '$lib/store';
  import { connectWallet } from '$lib/helpers/wallet.js';

  // İlk sahte bakiye
  balances.set({ tether: 50000 });
</script>

<Header on:click={connectWallet} />
<BalanceBox />
<SwapBox />

<hr class="my-8 border-gray-200 w-4/5 mx-auto" />

<section class="px-4 max-w-7xl mx-auto">
  <h2 class="text-2xl font-bold text-center mb-6">Latest Crypto News</h2>
  <Blogs />
</section>

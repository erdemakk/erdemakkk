<script>
  import { createEventDispatcher } from 'svelte';
  const dispatch = createEventDispatcher();

  function handleClick() {
    dispatch('click');
  }
</script>

<header class="bg-gray-800 text-white flex items-center justify-between px-4 py-3 shadow-md">
  <h1 class="text-xl font-black font-sans text-white animate-typing-loop">
    ERD SWAP
  </h1>

  <img
    src="/payw-metamask.png"
    alt="Pay with MetaMask"
    class="w-40 cursor-pointer"
    on:click={handleClick}
  />
</header>

<script>
  import { account, balances } from '$lib/store';
</script>

{#if $account}
  <div class="absolute top-[80px] right-6 w-64 bg-white border border-gray-300 shadow-md rounded-xl p-4 z-10">
    <h3 class="text-center text-lg font-bold text-gray-800 mb-3">Wallet Balances</h3>

    <ul class="text-sm space-y-2 text-gray-700 max-h-64 overflow-auto">
      {#each Object.entries($balances) as [coin, value]}
        {#if value > 0}
          <li class="flex justify-between border-b pb-1">
            <span class="font-medium">{coin.toUpperCase()}</span>
            <span>{value}</span>
          </li>
        {/if}
      {/each}
    </ul>
  </div>
{/if}

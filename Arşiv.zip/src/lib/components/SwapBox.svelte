<script>
  import {onMount} from "svelte";
  import coinSelect from '$lib/components/CoinSelect.svelte';
  import { account, balances, tradeHistory } from "$lib/store.js";
  import { get } from "svelte/store";

  let coins = [];
  let fromCoin = 'tether';
  let toCoin = 'bitcoin';
  let amount = '';
  let result = null;
  let exchangeRate = null;

  let showSuccess = false;
  let successMessage = '';

  onMount(async () => {
    const res = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&per_page=50&page=1');
    const data = await res.json();
    coins = data.map(coin => ({
      id: coin.id,
      name: coin.name,
      symbol: coin.symbol,
      image: coin.image
    }));
  });

  $: if (fromCoin && toCoin && amount && !isNaN(amount) && number(amount) > 0) {
    fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${fromCoin},${toCoin}&vs_currencies=usd`)
      .then(res => res.json())
      .then(data => {
        const fromPrice = data[fromCoin]?.usd;
        const toPrice = data[toCoin]?.usd;

        if (fromPrice && toPrice) {
        exchangeRate = toPrice / fromPrice;
        result = (Number(amount) * exchangeRate).toFixed(6);
        } else {
          exchangeRate = null;
          result = null;
        }
      });
  } else {
    result = null;
    exchangeRate = null;
  }

  function fakeSwap() {
    const amt = parseFloat(amount);
    const resVal = parseFloat(result);

    if (!amt || isNaN(amt) || amt <= 0 || !resVal || !get(account)) return;

    const currentBalances = get(balances);
    if ((currentBalances[fromCoin] || 0) < resVal) {
      alert(`Insufficient ${fromCoin.toUpperCase()} balance.`);
      return;
    }

    const newBalances = { ...currentBalances };
    newBalances[fromCoin] = parseFloat((newBalances[fromCoin] - resVal).toFixed(6));
    newBalances[toCoin] = parseFloat(((newBalances[toCoin] || 0) + amt).toFixed(6));

    for (const key in newBalances) {
      if (newBalances[key] === 0) delete newBalances[key];
    }

    balances.set(newBalances);

    tradeHistory.update((list) => [
      {
        from: fromCoin,
        to: toCoin,
        amount: amt,
        result: resVal
      },
      ...list
    ]);

    successMessage = `Swapped ${resVal} ${fromCoin.toUpperCase()} → ${amt} ${toCoin.toUpperCase()}`;
    showSuccess = true;
    setTimeout(() => (showSuccess = false), 3000);
  }

</script>
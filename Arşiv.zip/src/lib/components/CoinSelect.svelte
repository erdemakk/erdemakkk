<script>
  export let coins = [];
  export let selected = '';
  export let exclude = '';

  let isOpen = false;

  function toggleDropdown() {
    isOpen = !isOpen;
  }

  function selectCoin(coinId) {
    selected = coinId;
    isOpen = false;
  }
</script>

<div class="relative">
  <button
    class="w-full border border-gray-300 rounded p-2 text-left flex items-center justify-between"
    on:click={toggleDropdown}
  >
    {#if selected}
      {#each coins as coin}
        {#if coin.id === selected}
          <div class="flex items-center space-x-2">
            <img src={coin.image} alt={coin.name} class="w-5 h-5" />
            <span>{coin.name} ({coin.symbol.toUpperCase()})</span>
          </div>
        {/if}
      {/each}
    {:else}
      <span class="text-gray-500">Select a coin</span>
    {/if}
  </button>

  {#if isOpen}
    <ul class="absolute z-10 bg-white border mt-1 w-full max-h-60 overflow-y-auto shadow rounded">
      {#each coins as coin (coin.id)}
        {#if coin.id !== exclude}
          <li
            class="p-2 hover:bg-gray-100 cursor-pointer flex items-center space-x-2"
            on:click={() => selectCoin(coin.id)}
          >
            <img src={coin.image} alt={coin.name} class="w-5 h-5" />
            <span>{coin.name} ({coin.symbol.toUpperCase()})</span>
          </li>
        {/if}
      {/each}
    </ul>
  {/if}
</div>
